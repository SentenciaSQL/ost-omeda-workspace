export const environmentProd = {
  production: true,
  chatbotBundleUrl: 'https://cdn.yourdomain.com/chatbot/prod/omeda-chatbot.js',
};
