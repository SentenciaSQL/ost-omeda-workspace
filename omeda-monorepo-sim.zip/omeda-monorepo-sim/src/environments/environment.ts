export const environment = {
  production: false,
   chatbotBundleUrl: 'http://localhost:4201/main.js',
  //  chatbotBundleUrl: 'http://localhost:4201/omeda-chatbot.js', // dev: local chatbot dev server
  // When the real chatbot bundle is deployed:
  // chatbotBundleUrl: 'https://cdn.yourdomain.com/chatbot/dev/omeda-chatbot.js',
  // chatbotScripts: [
  //   'http://localhost:4201/polyfills.js',  chatbotBundleUrl: 'http://localhost:4201/omeda-chatbot.js', // dev: local chatbot dev server
  //   'http://localhost:4201/main.js',
  // ],
};
